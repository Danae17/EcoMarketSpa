package com.ecomarketspa.ecomarket_spa.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ecomarketspa.ecomarket_spa.model.Inventario;
import com.ecomarketspa.ecomarket_spa.repository.InventarioRepository;

@Service
public class InventarioService {

    @Autowired
    private InventarioRepository inventarioRepository;

    public List<Inventario> obtenerTodos() {
        return inventarioRepository.findAll();
    }

    public Optional<Inventario> obtenerPorId(Long id) {
        return inventarioRepository.findById(id);
    }

    public Inventario crear(Inventario inventario) {
        return inventarioRepository.save(inventario);
    }

    public Inventario actualizar(Long id, Inventario actualizado) {
        return inventarioRepository.findById(id)
                .map(inv -> {
                    inv.setProducto(actualizado.getProducto());
                    inv.setSucursal(actualizado.getSucursal());
                    return inventarioRepository.save(inv);
                })
                .orElse(null);
    }

    public void eliminar(Long id) {
        inventarioRepository.deleteById(id);
    }
}
