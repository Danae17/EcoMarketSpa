package com.ecomarketspa.ecomarket_spa.model;

import jakarta.persistence.*;
import lombok.Data;

import java.util.List;

@Data
@Entity
@Table(name = "tipousuario")
public class Tipo_usuario {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    @Column(nullable = false)
    private String claseUsuario;  

    @OneToMany(mappedBy = "tipousuario", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Usuario> usuarios;
}
