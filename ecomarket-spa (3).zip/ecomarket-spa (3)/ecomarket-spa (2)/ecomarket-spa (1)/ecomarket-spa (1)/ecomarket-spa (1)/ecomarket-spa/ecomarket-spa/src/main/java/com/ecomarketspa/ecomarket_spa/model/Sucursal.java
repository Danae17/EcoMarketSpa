package com.ecomarketspa.ecomarket_spa.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "sucursal")
public class Sucursal {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String nombre;

    private String direccion;

    @ManyToOne
    @JoinColumn(name = "comuna_id")
    private Comuna comuna;

    @OneToMany(mappedBy = "sucursal", cascade = CascadeType.ALL)
    private List<Venta> ventas;

    @OneToMany(mappedBy = "sucursal", cascade = CascadeType.ALL)
    private List<Inventario> inventario;
}
