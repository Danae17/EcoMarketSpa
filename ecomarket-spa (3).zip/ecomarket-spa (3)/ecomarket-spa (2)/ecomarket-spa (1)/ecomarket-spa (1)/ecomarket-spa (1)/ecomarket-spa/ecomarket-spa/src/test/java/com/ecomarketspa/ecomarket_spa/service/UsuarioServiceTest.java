package com.ecomarketspa.ecomarket_spa.service;


import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions;


import com.ecomarketspa.ecomarket_spa.model.Usuario;
import com.ecomarketspa.ecomarket_spa.repository.Usuario;
import java.util.List;
import java.util.Optional;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;


import java.beans.Transient;




@SpringBootTest
public class UsuarioServiceTest {
    @Autowired
    private UsuarioService usuarioService;


    @MockBean
    private UsuarioRepository usuarioRepository;


    @Test
    public void testFindAll() {
        when(usuarioRepository.findAll()).thenReturn(List.of(new Usuario()));


        List<Usuario> usuario = usuarioService.findAll();


        assertNotNull(usuario);
        assertEquals(1,usuario.size());


    }


    @Test
    public void testFindByCodigo(){
        String codigo = "1";
        Usuario usuario = new Usuario();


        when(usuarioRepository.findById(codigo)).thenReturn(Optional.of(usuario));
        Usuario found = usuarioService.testFindByCodigo(codigo);


        assertNotNull(found);
        assertEquals(null, found.getCodigo());


    }


    @Test
    public void testSave() {
        Usuario usuario = new Usuario();


        when(usuarioRepository.save(usuario)).thenReturn(usuario);
        usuario saved = usuarioService.save(usuario);


        assertNotNull(saved);
        assertEquals(null, saved.getNombre());


    }


    @Test
    public void testDeleteByCodigo(){
        String codigo = "1";


        doNothing().when(usuarioRepository).deleteById(codigo);


        usuarioService.deleteByCodigo(codigo);


        verify(usuarioRepository, times(1)).deleteById(codigo);
    }


}

