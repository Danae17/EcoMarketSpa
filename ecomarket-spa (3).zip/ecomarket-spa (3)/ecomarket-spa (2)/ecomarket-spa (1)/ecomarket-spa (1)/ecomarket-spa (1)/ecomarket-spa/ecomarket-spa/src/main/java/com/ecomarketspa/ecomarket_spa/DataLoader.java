package com.ecomarketspa.ecomarket_spa;

import net.datafaker.Faker;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

import com.ecomarketspa.ecomarket_spa.model.Pedido;
import com.ecomarketspa.ecomarket_spa.repository.CarritoRepository;

import java.time.LocalDate;
import java.util.Date;
import java.util.List;
import java.util.Random;

import javax.swing.plaf.basic.BasicInternalFrameTitlePane.TitlePaneLayout;

@Profile("dev")
@Component
public class DataLoader implements CommandLineRunner{
    
    @Autowired
    private PedidoRepository PedidoRepository;
    @Autowired
    private ProductoRepository ProductoRepository;

    @Autowired
    private UsuarioRepository UsuarioRepository;
    


    @Override
    public void run(String... args) throws Exception {
        Faker faker = new Faker();
        Random random = new Random();

               //Generar tipos de productos
        for (int i = 0; i < 10; i++){
            Producto producto = new Producto();
            producto.setIdProducto();
            producto.setNombre(faker.book().genre());
            producto.setDescripcion(faker.lorem().sentence());
            producto.setPrecio(Double.parseDouble(faker.commerce().price()));
            prodcutoRepository.save(producto);
        }


       
        //Generar tipos de usuario
        for (int i = 0; i < 5; i++){
            Usuario usuario = new Usuario();
            usuario.setIdUsuario(i + 1);
            usuario.setNombre(faker.book().genre());
            usuario.setApellido(faker.book().genre());
            usuario.setCorreo(faker.internet().emailAddress());
            usuario.setDireccion(faker.address().fullAddress());
            usuarioRepository.save(usuario);
        }


        for (int i = 0; i < 5; i++){
            Pedido pedido = new Pedido();
            pedido.setIdPedido();
            pedido.setNombre(faker.book().genre());
            pedido.setFecha(LocalDate.now().minusDays(faker.number().numberBetween(1, 30)));
            pedido.setTotal(faker.number().randomDouble(2, 10000, 200000));
            pedido.setUsuario(usuarioRepository.findAll().get(random.nextInt(5)));
            pedidoRepository.save(pedido);
        }


    }


}
