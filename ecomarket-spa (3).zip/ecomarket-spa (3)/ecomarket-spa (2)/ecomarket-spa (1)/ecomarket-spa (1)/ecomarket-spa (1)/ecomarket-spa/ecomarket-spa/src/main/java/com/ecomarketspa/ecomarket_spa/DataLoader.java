package com.ecomarketspa.ecomarket_spa;

import net.datafaker.Faker;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

import com.ecomarketspa.ecomarket_spa.model.Pedido;
import com.ecomarketspa.ecomarket_spa.model.Producto;
import com.ecomarketspa.ecomarket_spa.model.Usuario;
import com.ecomarketspa.ecomarket_spa.repository.PedidoRepository;
import com.ecomarketspa.ecomarket_spa.repository.ProductoRepository;
import com.ecomarketspa.ecomarket_spa.repository.UsuarioRepository;


import java.time.LocalDate;
import java.util.Date;
import java.util.List;
import java.util.Random;

import javax.swing.plaf.basic.BasicInternalFrameTitlePane.TitlePaneLayout;

@Profile("dev")
@Component
public class DataLoader implements CommandLineRunner{
    
    @Autowired
    private PedidoRepository PedidoRepository;
    @Autowired
    private ProductoRepository ProductoRepository;

    @Autowired
    private UsuarioRepository UsuarioRepository;
    


    @Override
    public void run(String... args) throws Exception {
        
        Faker faker = new Faker();
        Random random = new Random();

        //Generar  productos
        for (int i = 0; i < 20; i++){
           Producto producto = new Producto();
            producto.setIdProducto(i + 1);
            producto.setNombre(faker.commerce().name());
            producto.setDescripcion(faker.lorem().sentence());
            producto.setPrecio(Double.parseDouble(faker.commerce().price()));
            prodcutoRepository.save(producto);
        }

        List<Producto> producto = productoRepository.finAll();

       
        //Generar usuario
        for (int i = 0; i < 10; i++){
            Usuario usuario = new Usuario();
            usuario.setIdUsuario(i + 1);
            usuario.setNombres(faker.name().fullName());
            usuario.setApellido(faker.name().lastname());
            usuario.setCorreo(faker.internet().emailAddress());
            usuario.setDireccion(faker.address().fullAddress());
            usuarioRepository.save(usuario);
        }
        

        //Generar pedido
        for (int i = 0; i < 10; i++){
            Pedido pedido = new Pedido();
            pedido.setIdPedido(i + 1);
            pedido.setNombre(faker.name().genre());
            pedido.setFecha(LocalDate.now().minusDays(faker.number().numberBetween(1, 30)));
            pedido.setTotal(faker.number().randomDouble(2, 10000, 200000));
            pedido.setEstado("Pendiente");
            pedido.setUsuario(usuario.get(random.nextIn(usuario.size())));
            pedido.setproducto(producto.get(random.nextInt(producto.size())));
            pedidoRepository.save(pedido);
        }

        List<Usuario> usuarios = usuarioRepository.finAll();
        


    }


}
