package com.ecomarketspa.ecomarket_spa.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Entity
@Table(name = "detalleventa")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class DetalleVenta {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    @ManyToOne
    @JoinColumn(name = "venta_id", nullable = false)
    private Venta venta;

    @ManyToOne
    @JoinColumn(name = "producto_id", nullable = false)
    private Producto producto;

    private Integer cantidad;

    private Double precioUnitario;

    private Double subtotal;

    private LocalDateTime fecha;

    @PrePersist
    public void calcularSubtotal() {
        if (subtotal == null && cantidad != null && precioUnitario != null) {
            subtotal = cantidad * precioUnitario;
        }
        if (fecha == null) {
            fecha = LocalDateTime.now();
        }
    }
}
