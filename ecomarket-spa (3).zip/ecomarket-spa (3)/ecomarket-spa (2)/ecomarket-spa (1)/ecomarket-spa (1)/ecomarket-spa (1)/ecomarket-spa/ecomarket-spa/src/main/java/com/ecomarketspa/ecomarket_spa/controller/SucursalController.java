package com.ecomarketspa.ecomarket_spa.controller;

import com.ecomarketspa.ecomarket_spa.model.Sucursal;
import com.ecomarketspa.ecomarket_spa.repository.SucursalRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/sucursales")
@CrossOrigin(origins = "*") 
public class SucursalController {

    @Autowired
    private SucursalRepository sucursalRepository;

    @GetMapping
    public List<Sucursal> listar() {
        return sucursalRepository.findAll();
    }

    @GetMapping("/{id}")
    public Sucursal obtenerPorId(@PathVariable Long id) {
        return sucursalRepository.findById(id).orElse(null);
    }

    @PostMapping
    public Sucursal crear(@RequestBody Sucursal sucursal) {
        return sucursalRepository.save(sucursal);
    }

    @PutMapping("/{id}")
    public Sucursal actualizar(@PathVariable Long id, @RequestBody Sucursal sucursalActualizada) {
        return sucursalRepository.findById(id).map(sucursal -> {
            sucursal.setNombre(sucursalActualizada.getNombre());
            sucursal.setDireccion(sucursalActualizada.getDireccion());
            sucursal.setComuna(sucursalActualizada.getComuna());
            return sucursalRepository.save(sucursal);
        }).orElse(null);
    }

    @DeleteMapping("/{id}")
    public void eliminar(@PathVariable Long id) {
        sucursalRepository.deleteById(id);
    }
}
