package com.ecomarketspa.ecomarket_spa.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ecomarketspa.ecomarket_spa.model.Comuna;
import com.ecomarketspa.ecomarket_spa.repository.ComunaRepository;

@Service
public class ComunaService {

    @Autowired
    private ComunaRepository comunaRepository;

    public List<Comuna> obtenerTodas() {
        return comunaRepository.findAll();
    }

    public Optional<Comuna> obtenerPorId(Long id) {
        return comunaRepository.findById(id);
    }

    public Comuna crear(Comuna comuna) {
        return comunaRepository.save(comuna);
    }

    public Comuna actualizar(Long id, Comuna actualizada) {
        return comunaRepository.findById(id).map(c -> {
            c.setNombre(actualizada.getNombre());
            return comunaRepository.save(c);
        }).orElse(null);
    }

    public void eliminar(Long id) {
        comunaRepository.deleteById(id);
    }
}
