package com.ecomarketspa.ecomarket_spa.controller;

import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ecomarketspa.ecomarket_spa.model.Usuario;
import com.ecomarketspa.ecomarket_spa.repository.Usuario;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.util.List;

@WebMvcTest(UsuarioController.class) 
public class UsuarioControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private UsuarioService usuarioService;

    @Autowired
    private ObjectMapper ObjectMapper;
    private Usuario usuario;

    @BeforeEach
    void setUp(){
        usuario = new Usuario();
        usuario.setId(1);
        usuario.setNombre("Juan Antonio");
        usuario.setApellidos("Gomez Lopez");
        usuario.setCorreo("Juan.Antonio@gmail.com");
        usuario.setDireccion("san carlos 1658" );
    }

    @Test
    public void testGetAllUsuario() throws Exception {
    
        when(usuarioService.findAll()).thenReturn(List.of(usuario));

        mockMvc.perform(get("/api/usuarios"))
                .andExpect(status().isOk()) 
                .andExpect(jsonPath("$[0].id").value(1)) 
                .andExpect(jsonPath("$[0].nombres").value("Juan Antonio"))
                .andExpect(jsonPath("$[0].apellidos").value("Gomez Lopez"))
                .andExpect(jsonPath("$[0].correo").value("Juan.Antonio@gmail.com"))
                .andExpect(jsonPath("$[0].direccion").value("san carlos 1658")); 
    }

    @Test
    public void testGetUsuarioById() throws Exception {
    
        when(usuarioService.findById(1)).thenReturn(usuario);

        mockMvc.perform(get("/api/usuarios/1"))
                .andExpect(status().isOk()) 
                .andExpect(jsonPath("$.id").value(1)) 
                .andExpect(jsonPath("$[0].nombres").value("Juan Antonio"))
                .andExpect(jsonPath("$[0].apellidos").value("Gomez Lopez"))
                .andExpect(jsonPath("$[0].correo").value("Juan.Antonio@gmail.com"))
                .andExpect(jsonPath("$[0].direccion").value("san carlos 1658")); 
    }

    @Test
    public void testCreateEstudiante() throws Exception {
        
        when(usuarioService.save(any(Usuario.class))).thenReturn(usuario);
        mockMvc.perform(post("/api/usuarios")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(usuario))) 
                .andExpect(status().isOk()) 
                .andExpect(jsonPath("$.id").value(1)) 
                .andExpect(jsonPath("$[0].nombres").value("Juan Antonio"))
                .andExpect(jsonPath("$[0].apellidos").value("Gomez Lopez"))
                .andExpect(jsonPath("$[0].correo").value("Juan.Antonio@gmail.com"))
                .andExpect(jsonPath("$[0].direccion").value("san carlos 1658")); 
    }

    @Test
    public void testUpdateEstudiante() throws Exception {
        when(usuarioService.save(any(Usuario.class))).thenReturn(usuario);

        mockMvc.perform(put("/api/usuarios/1")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(estudiante))) 
                .andExpect(status().isOk()) 
                .andExpect(jsonPath("$.id").value(1)) 
                .andExpect(jsonPath("$[0].nombres").value("Juan Antonio"))
                .andExpect(jsonPath("$[0].apellidos").value("Gomez Lopez"))
                .andExpect(jsonPath("$[0].correo").value("Juan.Antonio@gmail.com"))
                .andExpect(jsonPath("$[0].direccion").value("san carlos 1658")); 
    }

    @Test
    public void testDeleteUsuario() throws Exception {
        
        doNothing().when(usuarioService).deleteById(1);

        mockMvc.perform(delete("/api/usuarios/1"))
                .andExpect(status().isOk()); 

        
        verify(usuarioService, times(1)).deleteById(1);
    }
}



