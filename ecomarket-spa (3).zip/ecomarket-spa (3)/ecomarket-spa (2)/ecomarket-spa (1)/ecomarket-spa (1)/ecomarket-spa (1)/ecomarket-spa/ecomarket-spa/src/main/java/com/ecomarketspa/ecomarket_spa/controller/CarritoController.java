package com.ecomarketspa.ecomarket_spa.controller;

import com.ecomarketspa.ecomarket_spa.model.Carrito;
import com.ecomarketspa.ecomarket_spa.model.Producto;
import com.ecomarketspa.ecomarket_spa.repository.CarritoRepository;
import com.ecomarketspa.ecomarket_spa.repository.ProductoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/carrito")
@CrossOrigin(origins = "*")
public class CarritoController {

    @Autowired
    private CarritoRepository carritoRepository;

    @Autowired
    private ProductoRepository productoRepository;

    @GetMapping
    public List<Carrito> listar() {
        return carritoRepository.findAll();
    }

    @GetMapping("/{id}")
    public Carrito obtener(@PathVariable Long id) {
        return carritoRepository.findById(id).orElse(null);
    }

    @PostMapping
    public Carrito crear(@RequestBody Carrito carrito) {
        return carritoRepository.save(carrito);
    }

    @DeleteMapping("/{id}")
    public void eliminar(@PathVariable Long id) {
        carritoRepository.deleteById(id);
    }

    @PostMapping("/{carritoId}/agregar-producto/{productoId}")
    public Carrito agregarProducto(@PathVariable Long carritoId, @PathVariable Long productoId) {
        Carrito carrito = carritoRepository.findById(carritoId).orElse(null);
        Producto producto = productoRepository.findById(productoId).orElse(null);

        if (carrito != null && producto != null) {
            carrito.getProductos().add(producto);
            return carritoRepository.save(carrito);
        }
        return null;
    }

    @DeleteMapping("/{carritoId}/eliminar-producto/{productoId}")
    public Carrito eliminarProducto(@PathVariable Long carritoId, @PathVariable Long productoId) {
        Carrito carrito = carritoRepository.findById(carritoId).orElse(null);
        Producto producto = productoRepository.findById(productoId).orElse(null);

        if (carrito != null && producto != null) {
            carrito.getProductos().remove(producto);
            return carritoRepository.save(carrito);
        }
        return null;
    }
}
