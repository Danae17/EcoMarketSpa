package com.ecomarketspa.ecomarket_spa.controller;

import com.ecomarketspa.ecomarket_spa.model.Tipo_usuario;
import com.ecomarketspa.ecomarket_spa.repository.Tipo_usuarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/tipousuarios")
@CrossOrigin(origins = "*")
public class TipoUsuarioController {

    @Autowired
    private Tipo_usuarioRepository tipoUsuarioRepository;

    @GetMapping
    public List<Tipo_usuario> listar() {
        return tipoUsuarioRepository.findAll();
    }

    @GetMapping("/{id}")
    public Tipo_usuario obtenerPorId(@PathVariable Long id) {
        return tipoUsuarioRepository.findById(id).orElse(null);
    }

    @PostMapping
    public Tipo_usuario crear(@RequestBody Tipo_usuario tipoUsuario) {
        return tipoUsuarioRepository.save(tipoUsuario);
    }

    @PutMapping("/{id}")
    public Tipo_usuario actualizar(@PathVariable Long id, @RequestBody Tipo_usuario tipoUsuarioActualizado) {
        return tipoUsuarioRepository.findById(id).map(tipo -> {
            tipo.setClaseUsuario(tipoUsuarioActualizado.getClaseUsuario());
            return tipoUsuarioRepository.save(tipo);
        }).orElse(null);
    }

    @DeleteMapping("/{id}")
    public void eliminar(@PathVariable Long id) {
        tipoUsuarioRepository.deleteById(id);
    }
}
