package com.ecomarketspa.ecomarket_spa.repository;

import com.ecomarketspa.ecomarket_spa.model.Comuna;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ComunaRepository extends JpaRepository<Comuna, Long> {
    
}
