package com.ecomarketspa.ecomarket_spa.repository;

import com.ecomarketspa.ecomarket_spa.model.Tipo_usuario;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface Tipo_usuarioRepository extends JpaRepository<Tipo_usuario, Long> {
}
