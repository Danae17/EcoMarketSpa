package com.ecomarketspa.ecomarket_spa.repository;

import com.ecomarketspa.ecomarket_spa.model.Inventario;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface InventarioRepository extends JpaRepository<Inventario, Long> {
    List<Inventario> findBySucursalId(Long sucursalId);
    List<Inventario> findByProductoId(Long productoId);
}
