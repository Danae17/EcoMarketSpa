package com.ecomarketspa.ecomarket_spa.controller;


import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ecomarketspa.ecomarket_spa.model.Pedido;
import com.ecomarketspa.ecomarket_spa.repository.Pedido;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;


import java.util.Date;
import java.util.List;


@WebMvcTest(PedidoController.class)
public class PedidoControllerTest {


    @Autowired
    private MockMvc mockMvc;


    @MockBean
    private PedidoService pedidoService;


    @Autowired
    private ObjectMapper ObjectMapper;
    private Pedido pedido;


    @BeforeEach
    void setUp(){
        pedido = new Pedido();
        pedido.setId(1);
        pedido.setFecha(new Date());
        pedido.setTotal();
        pedido.setEstado(1);
    }


    @Test
    public void testGetAllProducto() throws Exception {
        when(pedidoService.findAll()).thenReturn(List.of(producto));


       
        mockMvc.perform(get("/api/pedidos"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].id").value(1))
                .andExpect(jsonPath("$[0].estado").value(1));
    }
   


    @Test
    public void testGetPedidoById() throws Exception {
       
        when(pedidoService.findById(1)).thenReturn(producto);


       
        mockMvc.perform(get("/api/pedidos/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1))
                .andExpect(jsonPath("$.estado").value(1));
    }
               
   


    @Test
    public void testCreatePedido() throws Exception {
        when(pedidoService.save(any(Pedido.class))).thenReturn(pedido);


        mockMvc.perform(post("/api/pedidos")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(pedido)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1))
                .andExpect(jsonPath("$.estado").value(1));
    }
   


    @Test
    public void testUpdateP() throws Exception {


        when(pedidoService.save(any(Pedido.class))).thenReturn(pedido);


       
        mockMvc.perform(put("/api/pedidos/1")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(pedido)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1))
                .andExpect(jsonPath("$.estado").value(1));
    }
   


    @Test
    public void testDeletePedido() throws Exception {
       
        doNothing().when(pedidoService).deleteById(1);
        mockMvc.perform(delete("/api/pedidos/1"))
                .andExpect(status().isOk());


        verify(pedidoService, times(1)).deleteById(1);
    }


}

