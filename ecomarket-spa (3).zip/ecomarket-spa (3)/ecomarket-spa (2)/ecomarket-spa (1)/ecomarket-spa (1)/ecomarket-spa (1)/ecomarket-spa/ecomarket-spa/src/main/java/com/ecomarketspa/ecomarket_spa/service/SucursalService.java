package com.ecomarketspa.ecomarket_spa.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ecomarketspa.ecomarket_spa.model.Sucursal;
import com.ecomarketspa.ecomarket_spa.repository.SucursalRepository;

@Service
public class SucursalService {

    @Autowired
    private SucursalRepository sucursalRepository;

    public List<Sucursal> obtenerTodas() {
        return sucursalRepository.findAll();
    }

    public Optional<Sucursal> obtenerPorId(Long id) {
        return sucursalRepository.findById(id);
    }

    public Sucursal crear(Sucursal sucursal) {
        return sucursalRepository.save(sucursal);
    }

    public Sucursal actualizar(Long id, Sucursal actualizada) {
        return sucursalRepository.findById(id).map(suc -> {
            // agregar campos si tienes más atributos como nombre, dirección, etc.
            return sucursalRepository.save(suc);
        }).orElse(null);
    }

    public void eliminar(Long id) {
        sucursalRepository.deleteById(id);
    }
}
