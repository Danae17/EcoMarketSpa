package com.ecomarketspa.ecomarket_spa.service;

import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions;

import com.ecomarketspa.ecomarket_spa.model.Producto;
import com.ecomarketspa.ecomarket_spa.repository.Producto;
import java.util.List;
import java.util.Optional;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import java.beans.Transient;


@SpringBootTest
public class ProductoServiceTest {
    @Autowired
    private ProductoService productoService;

    @MockBean
    private ProductoRepository productoRepository;

    @Test 
    public void testFindAll() {
        when(productoRepository.findAll()).thenReturn(List.of(new Producto(1,"Teclado mecánico", 18.900,"Gaming")));

        List<Producto> producto = productoService.findAll();

        assertNotNull(producto);
        assertEquals(1,producto.size());

    }

    @Test 
    public void testFindById(){
        String id = 1;
        Producto producto= new Producto(Id, null );

        when(productoRepository.findById(Id)).thenReturn(Optional.of(c));
        Producto found = productoService.FindById(id);

        assertNotNull(found);
        assertEquals(null, found.getCodigo());
    }

    @Test
    public void testSave() {
        Producto producto = new Producto(1,"Teclado mecánico", 18.990, "Gaming");

        when(productoRepository.save(producto)).thenReturn(producto);
        producto saved = productoService.save(producto);

        assertNotNull(saved);
        assertEquals("Teclado mecánico", saved.getNombre());

    }

    @Test
    public void testDeleteById(){
        String id = 1;

        doNothing().when(productoRepository).deleteById(id);

        productoService.deleteByCodigo(id);

        verify(productoRepository, times(1)).deleteById(id);
    }

}
