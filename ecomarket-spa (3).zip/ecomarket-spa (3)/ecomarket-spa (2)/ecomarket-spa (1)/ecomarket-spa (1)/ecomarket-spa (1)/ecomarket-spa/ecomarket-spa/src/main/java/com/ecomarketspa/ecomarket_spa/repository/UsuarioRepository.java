package com.ecomarketspa.ecomarket_spa.repository;

import com.ecomarketspa.ecomarket_spa.model.Usuario;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface UsuarioRepository extends JpaRepository<Usuario, Long> {

    /*List<Usuario> findBynombre(String nombre);
    List<Usuario> findByapellidos(String apellidos);

    Usuario findBycorreo(String correo);

    List<Usuario> findBynombreAndapellidos(String nombre, String apellidos); */

    @Query("SELECT u FROM Usuario u WHERE u.apellidos= :apellido")
    List<Usuario> buscarPornombreAndapellidos(@Param("apellidos") String apellidos);

    @Query(value = "SELECT * FROM Usuario WHERE correo= :correo", nativeQuery = true)
    Usuario buscarPorcorreo(@Param("correo") String correo);


}
