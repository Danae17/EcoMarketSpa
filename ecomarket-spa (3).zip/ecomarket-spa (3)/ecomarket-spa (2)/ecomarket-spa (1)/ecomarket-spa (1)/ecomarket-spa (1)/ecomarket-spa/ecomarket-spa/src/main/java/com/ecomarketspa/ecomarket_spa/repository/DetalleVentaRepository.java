package com.ecomarketspa.ecomarket_spa.repository;

import com.ecomarketspa.ecomarket_spa.model.DetalleVenta;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DetalleVentaRepository extends JpaRepository<DetalleVenta, Long> {
}
