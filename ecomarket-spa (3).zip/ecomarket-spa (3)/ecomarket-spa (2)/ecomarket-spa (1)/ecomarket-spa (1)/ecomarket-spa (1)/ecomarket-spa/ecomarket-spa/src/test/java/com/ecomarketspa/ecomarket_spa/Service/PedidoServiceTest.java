package com.ecomarketspa.ecomarket_spa.service;

import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions;

import java.util.List;
import java.util.Optional;

import com.ecomarketspa.ecomarket_spa.model.Pedido;
import com.ecomarketspa.ecomarket_spa.repository.Pedido;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import java.beans.Transient;

@SpringBootTest
@ActiveProfiles("test")
public class PedidoServiceTest {
    @Autowired
    private PedidoService pedidoService;

    @MockBean
    private PedidoRepository pedidoRepository;

    @Test 
    public void testFindAll() {
        Pedido pedido = crearPedido();
        when(pedidoRepository.findAll()).thenReturn(List.of(pedido));
        List <Pedido> pedidos = pedidoService.findAll();

        assertNotNull(pedido);
        assertEquals(1,pedido.size());
        assertEquals(pedido.getId(), pedido.get(0).getId());

    }

    @Test 
    public void testFindByCodigo(){
        Integer id = 1;
        Pedido pedido = new Pedido();

        when(pedidoRepository.findById(codigo)).thenReturn(Optional.of(pedido));
        Pedido found = pedidoService.testFindByCodigo(codigo);

        assertNotNull(found);
        assertEquals(null, found.getCodigo());

    }

    @Test
    public void testSave() {
        Pedido pedido = crearPedido();
        when(pedidoRepository.save(pedido)).thenReturn(pedido);
        pedido saved = pedidoService.save(pedido);

        assertNotNull(saved);
        assertEquals(null, saved.getNombre());

    }

    @Test
    public void testDeleteById(){
        String id = 1;

        doNothing().when(pedidoRepository).deleteById(id);

        pedidoService.deleteByCodigo(id);

        verify(pedidoRepository, times(1)).deleteById(id);
    }

   

}
