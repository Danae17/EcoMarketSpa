package com.ecomarketspa.ecomarket_spa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EcomarketSpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
