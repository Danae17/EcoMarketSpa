package com.ecomarketspa.ecomarket_spa.service;

import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

import java.util.List;
import java.util.Optional;

import com.ecomarketspa.ecomarket_spa.model.Pedido;
import com.ecomarketspa.ecomarket_spa.model.Producto;
import com.ecomarketspa.ecomarket_spa.model.Usuario;
import com.ecomarketspa.ecomarket_spa.repository.PedidoRepository;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ActiveProfiles;

import java.beans.Transient;
import java.time.LocalDate;


@SpringBootTest
@ActiveProfiles("test")
public class PedidoServiceTest {

    @Autowired
    private PedidoService pedidoService;

    @MockBean
    private PedidoRepository pedidoRepository;
    
    private Pedido crearPedido() {
        Pedido pedido = new Pedido();
        pedido.setId(1L);
        pedido.setFecha(LocalDate.now());
        pedido.setEstado(1);
        pedido.setTotal(15.000);
        return pedido;
    }

    @Test
    public void testObtenerTodos() {
        Pedido pedido = crearPedido();
        when(pedidoRepository.findAll()).thenReturn(List.of(pedido));

        List <Pedido> pedidos = pedidoRepository.findAll();
        assertNotNull(pedidos);
        assertEquals(1, pedidos.size());
        assertEquals(pedido.getId(), pedidos.get(0).getId());


    }


    @Test
    public void testObtenerPorId() {
        Pedido pedido =  crearPedido();
        when(pedidoRepository.findById(1L)).thenReturn(Optional.of(pedido));
        
        Optional<Pedido> resultado = pedidoService.obtenerPorId(1L);

        assertTrue(resultado.isPresent());
        assertEquals(pedido.getVentas(), resultado.get().getVentas());


    }


    @Test
    public void testCrear() {
        Pedido pedido = crearPedido();
        when(pedidoRepository.save(pedido)).thenReturn(pedido);
        
        Pedido saved = pedidoService.crear(pedido);
        assertNotNull(saved);
        assertEquals(null, saved.getEstado());


    }


    @Test
    public void testEliminar(){

        doNothing().when(pedidoRepository).deleteById(1l);

        pedidoService.eliminar(1l);
        verify(pedidoRepository, times(1)).deleteById(1l);
    }



   


}


