package com.ecomarketspa.ecomarket_spa.controller;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ecomarketspa.ecomarket_spa.model.Producto;
import com.ecomarketspa.ecomarket_spa.service.ProductoService;
import com.ecomarketspa.ecomarket_spa.repository.ProductoRepository;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;


import java.util.List;
import java.util.Optional;


@WebMvcTest(ProductoController.class)
public class ProductoControllerTest {


    @Autowired
    private MockMvc mockMvc;


    @MockBean
    private ProductoService productoService;


    @Autowired
    private ObjectMapper ObjectMapper;
    private Producto producto;


    @BeforeEach
    void setUp(){
        producto = new Producto();
        producto.setId(1);
        producto.setNombre("Audífonos");
        producto.setPrecio(11.990);
        producto.setDescripcion("Inalámbricos");
    }


    @Test
    public void testObtenerTodos() throws Exception {
        when(productoService.obtenerTodos()).thenReturn(List.of(producto));
   
        mockMvc.perform(get("/api/productos"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].id").value(1))
                .andExpect(jsonPath("$[0].nombre").value("Audífono"))
                .andExpect(jsonPath("$[0].precio").value(11.990));
    }


    @Test
    public void testObtenerPorId() throws Exception {
        when(productoService.obtenerPorId(1L)).thenReturn(Optional.of(producto));

        mockMvc.perform(get("/api/productos/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].id").value(1))
                .andExpect(jsonPath("$[0].nombre").value("Audífono"))
                .andExpect(jsonPath("$[0].precio").value(11.990));    }


    @Test
    public void testCrear() throws Exception {
        when(productoService.crear(any(Producto.class))).thenReturn(producto);


        mockMvc.perform(post("/api/productos")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(ObjectMapper.writeValueAsString(producto)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].id").value(1))
                .andExpect(jsonPath("$[0].nombre").value("Audífono"))
                .andExpect(jsonPath("$[0].precio").value(11.990));    }


    @Test
    public void testActualizar() throws Exception {
        when(productoService.actualizar(eq(1L), any(Producto.class))).thenReturn(producto);


        mockMvc.perform(put("/api/productos/1")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(ObjectMapper.writeValueAsString(producto)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].id").value(1))
                .andExpect(jsonPath("$[0].nombre").value("Audífono"))
                .andExpect(jsonPath("$[0].precio").value(11.990));    }


    @Test
    public void testEliminar() throws Exception {
        doNothing().when(productoService).eliminar(1L);


        mockMvc.perform(delete("/api/productos/1"))
                .andExpect(status().isOk());


        verify(productoService, times(1)).eliminar(1L);
    }






}

