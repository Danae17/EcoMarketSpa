package com.ecomarketspa.ecomarket_spa.service;


import com.ecomarketspa.ecomarket_spa.model.Usuario;
import com.ecomarketspa.ecomarket_spa.repository.UsuarioRepository;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ActiveProfiles;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;




@SpringBootTest
public class UsuarioServiceTest {
    @Autowired
    private UsuarioService usuarioService;


    @MockBean
    private UsuarioRepository usuarioRepository;

    private Usuario crearUsuario() {
        Usuario usuario = new Usuario();
        usuario.setId(1L);
        usuario.setNombre("Camila");
        usuario.setCorreo("camila@gmail.com");
        usuario.setDireccion("Av. Principal 456");
        return usuario;
    }


    @Test
    public void testFindAll() {
        Usuario usuario = crearUsuario();
        when(usuarioRepository.findAll()).thenReturn(List.of(usuario));


        List<Usuario> usuarios = usuarioService.findAll();

        assertNotNull(usuarios);
        assertEquals(1, usuarios.size());
        assertEquals(usuario.getId(), usuarios.get(0).getId());


    }


    @Test
    public void testFindById(){
        Usuario usuario = crearUsuario();

        when(usuarioRepository.findById(1L)).thenReturn(Optional.of(usuario));
        
        Usuario encontrado = usuarioService.findById(1L); // No usa Optional en el service

        assertNotNull(encontrado);
        assertEquals("Camila", encontrado.getNombre());



    }


    @Test
    public void testSave() {
        Usuario usuario = crearUsuario();

        when(usuarioRepository.save(usuario)).thenReturn(usuario);
        Usuario saved = usuarioService.save(usuario);


        assertNotNull(saved);
        assertEquals(usuario.getNombre(), saved.getNombre());


    }


    @Test
    public void testDelete(){

        doNothing().when(usuarioRepository).deleteById(1l);

        usuarioService.delete(1L);

        verify(usuarioRepository, times(1)).deleteById(1L);
    }


}

