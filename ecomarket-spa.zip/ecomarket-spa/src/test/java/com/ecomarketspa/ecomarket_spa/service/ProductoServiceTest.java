package com.ecomarketspa.ecomarket_spa.service;


import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.*;




import com.ecomarketspa.ecomarket_spa.model.Producto;
import com.ecomarketspa.ecomarket_spa.repository.ProductoRepository;

import java.util.List;
import java.util.Optional;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;


import java.beans.Transient;




@SpringBootTest
public class ProductoServiceTest {
    @Autowired
    private ProductoService productoService;


    @MockBean
    private ProductoRepository productoRepository;


    private Producto crearProducto() {
        Producto producto = new Producto();
        producto.setId(1L);
        producto.setNombre("Manzana");
        producto.setDescripcion("Manzana roja orgánica");
        producto.setPrecio(1200.0);
        return producto;
    }


    @Test
    public void testObtenerTodos() {
        Producto producto = crearProducto();
        when(productoRepository.findAll()).thenReturn(List.of(new Producto()));

        List<Producto> productos = productoService.obtenerTodos();

        assertNotNull(productos);
        assertEquals(1,productos.size());
        assertEquals(producto.getId(), productos.get(0).getId());



    }


    @Test
    public void testObtenerPorId(){
        
        Producto producto = crearProducto();

        when(productoRepository.findById(1L)).thenReturn(Optional.of(producto));

        Optional<Producto> resultado = productoService.obtenerPorId(1L);

        assertTrue(resultado.isPresent());
        assertEquals(producto.getNombre(), resultado.get().getNombre());
    }


    @Test
    public void testCrear() {
        Producto producto = crearProducto();


        when(productoRepository.save(producto)).thenReturn(producto);
        Producto saved = productoService.crear(producto);


        assertNotNull(saved);
        assertEquals(producto.getNombre(), saved.getNombre());


    }


    @Test
    public void testEliminar(){
  
        doNothing().when(productoRepository).deleteById(1L);


        productoService.eliminar(1L);


        verify(productoRepository, times(1)).deleteById(1L);
    }


}

