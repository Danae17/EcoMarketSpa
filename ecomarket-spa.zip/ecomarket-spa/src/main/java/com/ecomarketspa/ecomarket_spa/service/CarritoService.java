package com.ecomarketspa.ecomarket_spa.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ecomarketspa.ecomarket_spa.model.Carrito;
import com.ecomarketspa.ecomarket_spa.repository.CarritoRepository;

@Service
public class CarritoService {

    @Autowired
    private CarritoRepository carritoRepository;

    public List<Carrito> obtenerTodos() {
        return carritoRepository.findAll();
    }

    public Optional<Carrito> obtenerPorId(Long id) {
        return carritoRepository.findById(id);
    }

    public Carrito crear(Carrito carrito) {
        return carritoRepository.save(carrito);
    }

    public Carrito actualizar(Long id, Carrito carritoActualizado) {
        return carritoRepository.findById(id)
                .map(carrito -> {
                    carrito.setUsuario(carritoActualizado.getUsuario());
                    return carritoRepository.save(carrito);
                })
                .orElse(null);
    }

    public void eliminar(Long id) {
        carritoRepository.deleteById(id);
    }
}
