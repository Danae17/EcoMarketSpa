package com.ecomarketspa.ecomarket_spa.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ecomarketspa.ecomarket_spa.model.Categoria;
import com.ecomarketspa.ecomarket_spa.repository.CategoriaRepository;

@Service
public class CategoriaService {

    @Autowired
    private CategoriaRepository categoriaRepository;

    public List<Categoria> obtenerTodas() {
        return categoriaRepository.findAll();
    }

    public Optional<Categoria> obtenerPorId(Long id) {
        return categoriaRepository.findById(id);
    }

    public Categoria crear(Categoria categoria) {
        return categoriaRepository.save(categoria);
    }

    public Categoria actualizar(Long id, Categoria categoriaActualizada) {
        return categoriaRepository.findById(id)
                .map(categoria -> {
                    categoria.setSkincare(categoriaActualizada.getSkincare());
                    categoria.setCuerpo(categoriaActualizada.getCuerpo());
                    categoria.setMascota(categoriaActualizada.getMascota());
                    return categoriaRepository.save(categoria);
                })
                .orElse(null);
    }

    public void eliminar(Long id) {
        categoriaRepository.deleteById(id);
    }
}
