package com.ecomarketspa.ecomarket_spa.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ecomarketspa.ecomarket_spa.model.Tipo_usuario;
import com.ecomarketspa.ecomarket_spa.repository.Tipo_usuarioRepository;

@Service
public class TipoUsuarioService {

    @Autowired
    private Tipo_usuarioRepository tipoUsuarioRepository;

    public List<Tipo_usuario> obtenerTodos() {
        return tipoUsuarioRepository.findAll();
    }

    public Optional<Tipo_usuario> obtenerPorId(Long id) {
        return tipoUsuarioRepository.findById(id);
    }

    public Tipo_usuario crear(Tipo_usuario tipoUsuario) {
        return tipoUsuarioRepository.save(tipoUsuario);
    }

    public Tipo_usuario actualizar(Long id, Tipo_usuario actualizado) {
        return tipoUsuarioRepository.findById(id).map(tu -> {
            tu.setClaseUsuario(actualizado.getClaseUsuario());
            return tipoUsuarioRepository.save(tu);
        }).orElse(null);
    }

    public void eliminar(Long id) {
        tipoUsuarioRepository.deleteById(id);
    }
}
