package com.ecomarketspa.ecomarket_spa.service;

import com.ecomarketspa.ecomarket_spa.model.DetalleVenta;
import com.ecomarketspa.ecomarket_spa.repository.DetalleVentaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class DetalleVentaService {

    @Autowired
    private DetalleVentaRepository detalleVentaRepository;

    
    public List<DetalleVenta> obtenerTodos() {
        return detalleVentaRepository.findAll();
    }

   
    public Optional<DetalleVenta> obtenerPorId(Long id) {
        return detalleVentaRepository.findById(id);
    }

    public DetalleVenta crear(DetalleVenta detalleVenta) {
        calcularSubtotal(detalleVenta);
        return detalleVentaRepository.save(detalleVenta);
    }

    public DetalleVenta actualizar(Long id, DetalleVenta actualizado) {
        Optional<DetalleVenta> existente = detalleVentaRepository.findById(id);
        if (existente.isPresent()) {
            DetalleVenta detalle = existente.get();
            detalle.setProducto(actualizado.getProducto());
            detalle.setCantidad(actualizado.getCantidad());
            detalle.setPrecioUnitario(actualizado.getPrecioUnitario());
            detalle.setFecha(actualizado.getFecha());
            detalle.setVenta(actualizado.getVenta());

            calcularSubtotal(detalle);
            return detalleVentaRepository.save(detalle);
        } else {
            return null;
        }
    }

    public void eliminar(Long id) {
        detalleVentaRepository.deleteById(id);
    }

    private void calcularSubtotal(DetalleVenta detalle) {
        if (detalle.getCantidad() != null && detalle.getPrecioUnitario() != null) {
            detalle.setSubtotal(detalle.getCantidad() * detalle.getPrecioUnitario());
        } else {
            detalle.setSubtotal(0.0);
        }
    }
}
