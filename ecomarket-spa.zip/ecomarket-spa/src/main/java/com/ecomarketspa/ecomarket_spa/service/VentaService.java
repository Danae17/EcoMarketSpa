package com.ecomarketspa.ecomarket_spa.service;

import com.ecomarketspa.ecomarket_spa.model.DetalleVenta;
import com.ecomarketspa.ecomarket_spa.model.Venta;
import com.ecomarketspa.ecomarket_spa.repository.VentaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class VentaService {

    @Autowired
    private VentaRepository ventaRepository;

    public List<Venta> obtenerTodasLasVentas() {
        return ventaRepository.findAll();
    }

    public Optional<Venta> obtenerVentaPorId(Long id) {
        return ventaRepository.findById(id);
    }

    public Venta crearVenta(Venta venta) {
        calcularTotal(venta);
        return ventaRepository.save(venta);
    }

    public Venta actualizarVenta(Long id, Venta ventaActualizada) {
        Optional<Venta> ventaExistente = ventaRepository.findById(id);
        if (ventaExistente.isPresent()) {
            Venta venta = ventaExistente.get();
            venta.setCliente(ventaActualizada.getCliente());
            venta.setEmpleado(ventaActualizada.getEmpleado());
            venta.setPedido(ventaActualizada.getPedido());
            venta.setSucursal(ventaActualizada.getSucursal());
            venta.setComunaEntrega(ventaActualizada.getComunaEntrega());
            venta.setFechaVenta(ventaActualizada.getFechaVenta());
            venta.setDetalles(ventaActualizada.getDetalles());

            calcularTotal(venta);
            return ventaRepository.save(venta);
        }
        return null;
    }

    public void eliminarVenta(Long id) {
        ventaRepository.deleteById(id);
    }

    private void calcularTotal(Venta venta) {
        double total = 0;
        if (venta.getDetalles() != null) {
            for (DetalleVenta detalle : venta.getDetalles()) {
                double subtotal = detalle.getCantidad() * detalle.getPrecioUnitario();
                detalle.setSubtotal(subtotal);
                detalle.setVenta(venta); // muy importante para la relación bidireccional
                total += subtotal;
            }
        }
        venta.setTotal(total);
    }
}
