package com.ecomarketspa.ecomarket_spa.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ecomarketspa.ecomarket_spa.model.Pedido;
import com.ecomarketspa.ecomarket_spa.repository.PedidoRepository;

@Service
public class PedidoService {

    @Autowired
    private PedidoRepository pedidoRepository;

    public List<Pedido> obtenerTodos() {
        return pedidoRepository.findAll();
    }

    public Optional<Pedido> obtenerPorId(Long id) {
        return pedidoRepository.findById(id);
    }

    public Pedido crear(Pedido pedido) {
        return pedidoRepository.save(pedido);
    }

    public Pedido actualizar(Long id, Pedido actualizado) {
        return pedidoRepository.findById(id)
                .map(pedido -> {
                    pedido.setVentas(actualizado.getVentas());
                    return pedidoRepository.save(pedido);
                })
                .orElse(null);
    }

    public void eliminar(Long id) {
        pedidoRepository.deleteById(id);
    }
}
