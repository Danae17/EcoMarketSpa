package com.ecomarketspa.ecomarket_spa.controller;

import com.ecomarketspa.ecomarket_spa.model.Inventario;
import com.ecomarketspa.ecomarket_spa.repository.InventarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/inventario")
@CrossOrigin(origins = "*")
public class InventarioController {

    @Autowired
    private InventarioRepository inventarioRepository;

    @GetMapping
    public List<Inventario> listar() {
        return inventarioRepository.findAll();
    }

    @GetMapping("/{id}")
    public Inventario obtener(@PathVariable Long id) {
        return inventarioRepository.findById(id).orElse(null);
    }

    @PostMapping
    public Inventario guardar(@RequestBody Inventario inventario) {
        return inventarioRepository.save(inventario);
    }

    @DeleteMapping("/{id}")
    public void eliminar(@PathVariable Long id) {
        inventarioRepository.deleteById(id);
    }

    @GetMapping("/sucursal/{sucursalId}")
    public List<Inventario> porSucursal(@PathVariable Long sucursalId) {
        return inventarioRepository.findBySucursalId(sucursalId);
    }

    @GetMapping("/producto/{productoId}")
    public List<Inventario> porProducto(@PathVariable Long productoId) {
        return inventarioRepository.findByProductoId(productoId);
    }
}
