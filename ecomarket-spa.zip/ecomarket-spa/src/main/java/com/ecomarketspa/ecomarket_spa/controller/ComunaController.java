package com.ecomarketspa.ecomarket_spa.controller;

import com.ecomarketspa.ecomarket_spa.model.Comuna;
import com.ecomarketspa.ecomarket_spa.repository.ComunaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/comunas")
@CrossOrigin(origins = "*")
public class ComunaController {

    @Autowired
    private ComunaRepository comunaRepository;

    @GetMapping
    public List<Comuna> listar() {
        return comunaRepository.findAll();
    }

    @GetMapping("/{id}")
    public Comuna obtenerPorId(@PathVariable Long id) {
        return comunaRepository.findById(id).orElse(null);
    }

    @PostMapping
    public Comuna crear(@RequestBody Comuna comuna) {
        return comunaRepository.save(comuna);
    }

    @PutMapping("/{id}")
    public Comuna actualizar(@PathVariable Long id, @RequestBody Comuna comunaActualizada) {
        return comunaRepository.findById(id).map(comuna -> {
            comuna.setNombre(comunaActualizada.getNombre());
            return comunaRepository.save(comuna);
        }).orElse(null);
    }

    @DeleteMapping("/{id}")
    public void eliminar(@PathVariable Long id) {
        comunaRepository.deleteById(id);
    }
}
